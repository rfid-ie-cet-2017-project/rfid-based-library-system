void serialr(char *);
void initr();
