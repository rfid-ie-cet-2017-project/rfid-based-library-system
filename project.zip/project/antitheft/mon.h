void initm();
void monw(char *);
//void monr(char *);

