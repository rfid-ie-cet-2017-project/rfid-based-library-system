void initm();
void monr(char *);
void monw(char *);

